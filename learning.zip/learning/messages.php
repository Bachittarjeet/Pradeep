<?php 

$messages = ["Login First Please!","Please type something before submitting!", "Invalid Email or Password","Successfully logged out!"];

?>
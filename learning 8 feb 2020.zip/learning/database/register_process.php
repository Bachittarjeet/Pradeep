<?php 
    
    include_once('connection.php');

    $email = $_POST["email"];
    $password = md5($_POST["password"]);
    $username = $_POST["username"];
    $flag = 1;
    $picture= null;

    $sql = "INSERT INTO `users`(`user_name`, `email`, `password`, `flag`, `picture`) VALUES ('$username','$email','$password',$flag,'$picture')";
    
    if ($mysqli->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    

?>
<?php 
$admin_email = "Admin@gmail.com";
$admin_password ='12345678';
?>
<?php 
    session_start();
    include_once('config.php');

    $email = $_POST["email"];
    $password = md5($_POST["password"]);

    if($email!="" && $password!=''){
        //Validation pass
        if($email==$admin_email && $password==md5($admin_password)){
            //Auth success
            $_SESSION["is_loggedin"] = 1;
            $_SESSION["email"] = $email;
            header("Location:adminhomepage.php");

        }else{
            //Auth Failed
            header("Location:index.php?m=2");
        }
    }else{
        //Validation Fail
        header("Location:index.php?m=1");
    }
?>
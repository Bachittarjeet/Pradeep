<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once('connection.php');

$json = array();
$sql = "SELECT * FROM users";
$result = $mysqli->query($sql);
//print_r($result);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $json[] = $row;
  }
  echo json_encode($json);
} else {
  echo "0 results";
}
?>
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$email = $_POST["email"];
$profile_picture_name = $_FILES["profile_picture"]["name"];
$profile_picture_tmp = $_FILES["profile_picture"]["tmp_name"];
$privacy_choice = $_POST["privacy_lock"];
$new_profile_picture_name = strval($_SERVER["REMOTE_ADDR"]).strval(time()).strval(rand()).$profile_picture_name;
$upload_dir = "./uploads/";

echo strval($_SERVER["REMOTE_ADDR"])." $email $privacy_choice $profile_picture_name $new_profile_picture_name";

move_uploaded_file($profile_picture_tmp,$upload_dir.$new_profile_picture_name);

?>
const express = require('express')
var path = require('path');
var mysql = require('mysql');
const { exit } = require('process');

const app = express()
const port = 3000



var con = mysql.createConnection({
    host: "127.0.0.1:8888",
    user: "root",
    password: "root",
    database: 'test'
});

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});




app.engine('html', require('ejs').renderFile);
// app.engine('.html', require('ejs').__express);
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'html');


app.get('/', function(req, res) {
    res.render('home.html');
})
app.get("/view/:username", function(req, res) {
    var users = [{ username: "John", age: 21 }, { username: "Raju", age: 22 }, { username: "Raju ka papa", age: 45 }];
    var username = req.params.username;
    var flag = false;
    var age = 0;
    for (var i = 0; i < users.length; ++i) {
        if (users[i].username == username) {
            flag = true;
            age = users[i].age;
            break;
        }
    }

    res.render("reddit.html", {
        username: username,
        userslist: users,
        age: age,
        flag: flag
    });
});

app.get('/users', function(req, res) {
    res.send('Users Lishbsdhfshdft')
})

app.get('*', function(req, res) {
    res.send('Lol')
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})
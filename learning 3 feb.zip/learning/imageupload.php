<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="col-md-6">
            <h1>Image upload Form</h1>
            <form action='./image_upload_process.php' method='post' enctype="multipart/form-data" >
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="email" name='email' value='admin@email.com'>
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone
                        else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Profile Picture</label>
                    <input type="file" id='profile_picture' accept="image/png, image/jpeg" name='profile_picture' class="form-control" >
                </div>
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="privacy_lock" name="privacy_lock" value='1'>
                    <label class="form-check-label" for="exampleCheck1">Profile Lock</label>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <br>
        </div>
        <div class="col-md-6">
        <img src="" id='img_preview' style='height:200px; width:200px' alt="">
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous">
    </script>
    <script>
    function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                    $('#img_preview').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }

        $("#profile_picture").change(function() {
            readURL(this);
        });
    </script>
</body>

</html>
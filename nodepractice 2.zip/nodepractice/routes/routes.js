const express = require('express')
const con = require('../db')
const router = express.Router();
router.use(express.urlencoded({
    extended: true
}));
router.get('/', (req, res, next) => {
    console.log("Checking Session");
    if (!req.session.email) {
        console.log("Session Logged Out");
        return res.redirect('/');
    }
    console.log("Session Logged In", req.session.user_id);
    var query = `SELECT * from Questions WHERE Questions.question_id NOT IN(
        SELECT Questions.question_id from Questions
        JOIN Submissions ON Submissions.question_id=Questions.question_id
        WHERE Submissions.user_id=?)`;
    con.query(query, [req.session.user_id], function(err, result, fields) {
            if (err) throw err;
            console.log(result);

            return res.render('app', { user_id: req.session.email, question: result[0] });
        })
        //res.render('app');
});


router.post('/answer', (req, res, next) => {

    var userid = req.session.user_id;
    var answer = req.body.answer;
    var question = req.body.question;
    console.log(userid, answer, question);
    // User Session check pass and now updating the user flag in users table
    var query = "INSERT into Submissions (user_id,question_id,answer) VALUES (?,?,?)";
    console.log(query);
    con.query(query, [userid, question, answer], function(err, result, fields) {
        if (err) throw err;
        return res.redirect('/app');
    });

    //res.send('HI');
});

module.exports = router;
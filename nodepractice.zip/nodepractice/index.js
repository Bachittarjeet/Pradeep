const express = require('express')
const app = express()
var mysql = require('mysql');
const session = require('express-session')
const port = 5000
app.use(express.urlencoded({
    extended: true
}));

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    port: 8889,
    database: 'learning'
});

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});

// Session Setup 
app.use(session({

    // It holds the secret key for session 
    secret: '9aa6e5f2256c17d2d430b100032b997c',

    // Forces the session to be saved 
    // back to the session store 
    resave: true,

    // Forces a session that is "uninitialized" 
    // to be saved to the store 
    saveUninitialized: true
}));

// set the view engine to ejs
app.set('view engine', 'ejs');

app.get('/', (req, res, next) => {
    res.render('index', { message: "" });
});

app.get('/logout', (req, res, next) => {
    req.session.destroy(function(err) {
        console.log("Session Destroyed");
    });
    res.redirect('/');
});

app.get('/admin', (req, res, next) => {
    if (!req.session.email) {
        return res.redirect('/');
    }
    var query = "SELECT * from users";
    con.query(query, function(err, result, fields) {
        if (err) throw err;
        res.render('admin', { email: req.session.email, users: result });
    })
});

app.get('/admin/:userid/:flag', (req, res, next) => {
    // Getting the user details
    var userid = req.params.userid;
    var flag = req.params.flag;

    // Check if the user is logged in
    if (!req.session.email) {
        return res.redirect('/');
    }

    // User Session check pass and now updating the user flag in users table
    var query = "UPDATE users SET flag=? WHERE user_id=?";
    con.query(query, [flag, userid], function(err, result, fields) {
        if (err) throw err;
        res.redirect('/admin');
    });

});


app.post('/submit-form', (req, res, next) => {
    const email = req.body.email;
    const password = req.body.password;
    var query = `SELECT * FROM users WHERE email='${email}' and password = '${password}' LIMIT 1`

    con.query(query, function(err, result, fields) {
        if (err) throw err;
        if (result.length == 1) {
            req.session.email = email
            return res.redirect('/admin')
        } else {
            res.render('index', { message: "User not found" });
        }

        console.log(result);
    });
    console.log(query);
});



app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
});

// MVC,MVVM,MVC2,MVW 
// Model - Database , View - Template , Controller - Business logic

// Model <-- Controller --> View
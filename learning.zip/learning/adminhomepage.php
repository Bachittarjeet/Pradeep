<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Area</title>
</head>
<body>
    <h1>Admin Area</h1>
    <?php 
        session_start();
        if(isset($_SESSION['is_loggedin']) && $_SESSION['is_loggedin']==1 ){
            echo "<h3>Welcome ".$_SESSION['email']."</h3>";
        }else{
            header("Location:index.php?m=0");
        }
    ?>
    
    
    <a href="./logout.php" class='btn btn-primary'>Logout</a>
</body>
</html>
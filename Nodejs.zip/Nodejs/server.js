const express = require('express')
var path = require('path');
var mysql = require('mysql');
const { exit } = require('process');
const app = express()
const port = 3000




app.engine('html', require('ejs').renderFile);
// app.engine('.html', require('ejs').__express);
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'html');
// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({
    extended: true
}));
// Parse JSON bodies (as sent by API clients)
app.use(express.json());
// Access the parse results as request.body
// app.post('/', function(request, response){
//     console.log(request.body.user.name);
//     console.log(request.body.user.email);
// });

var con = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "root",
    database: "learning",
    port: 8889
});

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});

app.get('/', function(req, res) {
    res.render('login.html');
})

app.post('/submit-form', function(request, res) {
    const email = request.body.email;
    const password = request.body.password;
    console.log(`SELECT * FROM users WHERE email='${email}' and password='${password}' `)

    con.query(`SELECT * FROM users WHERE email='${email}' and password='${password}' `, function(err, result, fields) {
        if (err) throw err;
        if (result.length > 0) {
            res.json({ message: "User exists" });
        } else {
            res.json({ message: "User does not exists" });
        }
        console.log(result);
    });

    //res.send("ok");
    // res.end();
});


app.get('/home', function(req, res) {
    res.render('homepage.html');
})

app.get("/view/:username", function(req, res) {
    var users = [{ username: "John", age: 21 }, { username: "Raju", age: 22 }, { username: "Raju ka papa", age: 45 }];
    var username = req.params.username;
    var flag = false;
    var age = 0;
    for (var i = 0; i < users.length; ++i) {
        if (users[i].username == username) {
            flag = true;
            age = users[i].age;
            break;
        }
    }

    res.render("reddit.html", {
        username: username,
        userslist: users,
        age: age,
        flag: flag
    });
});

app.get('/users', function(req, res) {
    res.send('Users Lishbsdhfshdft')
})

app.get('*', function(req, res) {
    res.send('Try Hack me!')
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})